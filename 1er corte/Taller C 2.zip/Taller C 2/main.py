from superhero import super_Heros

instanciaSuperHero = super_Heros()
instanciaSuperHero.MenuT()
